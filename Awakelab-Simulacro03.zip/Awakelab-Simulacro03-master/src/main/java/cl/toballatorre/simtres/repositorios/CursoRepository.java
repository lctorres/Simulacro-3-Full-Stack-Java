package cl.toballatorre.simtres.repositorios;

import org.springframework.data.jpa.repository.JpaRepository;

import cl.toballatorre.simtres.modelos.Curso;

public interface CursoRepository extends JpaRepository<Curso, Integer>{

}
